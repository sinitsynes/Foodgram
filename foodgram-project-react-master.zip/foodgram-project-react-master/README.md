# praktikum_new_diplom
